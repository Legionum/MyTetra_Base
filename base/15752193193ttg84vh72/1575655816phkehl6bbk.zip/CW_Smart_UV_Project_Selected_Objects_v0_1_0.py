bl_info = {
    "name": "Smart UV Project all selected objects (Stretch to UV Bounds OFF)",
	"author": "Christoph Werner",
	"version": (0, 1, 0),
    "blender": (2, 7, 9),
    "location": "Spacebar > Search",
    "description": "Tool for automatic Smart UV project to all selected objects. Every object gets a individual UVset (No single Atlas map will be generated!). Correct Aspect ON, Stretch to UV Bounds OFF. ",
    "warning": "Some functions in development!",
    "wiki_url": "http://www.christoph-werner.de/2018/08/03/smart-uv-project-all-selected-objects-blender-add-on/",
    "tracker_url": "",
    "category": "UV"
	}

import bpy


class cw_SmartUnwrapSelectedObjects(bpy.types.Operator):
    """Unwraps all selected objects by using the Smart Unwrap function without stretching UVs to texturebounds."""      # blender will use this as a tooltip for menu items and buttons.
    bl_idname = "object.smart_unwrap_selected"        # unique identifier for buttons and menu items to reference.
    bl_label = "Smart UV project selected objects"         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.

    def execute(self, context):        # execute() is called by blender when running the operator.

        # The actual script
        if bpy.context.selected_objects != []:
            for obj in bpy.context.selected_objects: #loop through all the selected objects
                if obj.type == 'MESH':
                    bpy.context.scene.objects.active = obj
                    bpy.ops.object.editmode_toggle() #entering edit mode
                    bpy.ops.mesh.select_all(action='SELECT') #select all objects elements
                    bpy.ops.uv.smart_project(stretch_to_bounds=0) #the actual unwrapping operation
                    bpy.ops.object.editmode_toggle() #exiting edit mode
                
        return {'FINISHED'}            # this lets blender know the operator finished successfully.

def register():
    bpy.utils.register_class(cw_SmartUnwrapSelectedObjects)


def unregister():
    bpy.utils.unregister_class(cw_SmartUnwrapSelectedObjects)

# This allows you to run the script directly from blenders text editor
# to test the addon without having to install it.
if __name__ == "__main__":
    register()